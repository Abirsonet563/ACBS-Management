/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test1.acbs_cafeteria_management_system;

/**
 *
 * @author Abir (01829740716)
 */
class itemIDToOrderField {
    
}
