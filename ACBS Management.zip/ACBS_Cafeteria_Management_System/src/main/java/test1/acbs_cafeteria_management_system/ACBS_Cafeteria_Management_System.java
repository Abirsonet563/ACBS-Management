/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package test1.acbs_cafeteria_management_system;

/**
 *
 * @author Abir (01829740716)
 */
public class ACBS_Cafeteria_Management_System {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
